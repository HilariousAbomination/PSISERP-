#pragma once
#include <string>

namespace th {

// PowerShell version the menu labels advertise. TermHost warns inside the tab
// if the installed pwsh.exe reports something different.
inline constexpr wchar_t kPwshVersion[] = L"7.6.7";

std::wstring FindPwsh();                                  // empty if not installed
std::wstring PwshFileVersion(const std::wstring& path);   // "major.minor.build" or empty
std::wstring FindCmd();                                   // %ComSpec% or System32\cmd.exe
std::wstring UserProfile();

}  // namespace th
