# TermHost: WinUI 3 tabbed terminal host (C++/WinRT)

Chrome-style `TabView` in the title bar, Mica backdrop, and a **+** button that opens a flyout with:

| Entry | What it does |
|---|---|
| PowerShell 7.6.7 | `pwsh.exe` on a ConPTY |
| PowerShell 7.6.7 (Administrator) | same, elevated through a UAC broker |
| Command Prompt / (Administrator) | `%ComSpec%` on a ConPTY, optionally elevated |
| Script Editor | `.ps1` editor + F5 run into a ConPTY output pane (optional elevated run) |
| Notepad Scratchpad | plain text box, persisted to `%LOCALAPPDATA%\TermHost\notepad.txt` |

> Status: written without a Windows toolchain, so it has **not been compiled**.
> Expect to fix a few small compile errors on first build.

## Create the project (about 5 minutes)

A hand-written `.vcxproj` for WinUI 3 is fragile, so let Visual Studio generate it:

1. Visual Studio 2022 (17.8+) with **Desktop development with C++** and **WinUI application development** workloads.
2. New project -> **Blank App, Packaged (WinUI 3 in Desktop)** (C++), named **`TermHost`** (the namespace must match).
3. Delete the template's `App.*`, `MainWindow.*`, `pch.*`; copy every file from this folder in and **Add -> Existing Item** for all of them.
4. Project properties (All Configurations):
   - **C/C++ -> Preprocessor**: add `DISABLE_XAML_GENERATED_MAIN`
   - **C/C++ -> Language**: C++20
   - `main.cpp` must be the only `wWinMain`; `App.idl` / `MainWindow.idl` need item type *Midl*.
5. Use an **unpackaged** exe (`<WindowsPackageType>None</WindowsPackageType>`, `<WindowsAppSDKSelfContained>true</WindowsAppSDKSelfContained>`). Packaged MSIX apps can't relaunch themselves with `runas`, which the admin tabs need.
6. Build x64 and run.

## How it fits together

- `main.cpp`: custom entry point. Launched as `--broker ...` it runs the elevated broker and never touches XAML.
- `ConPtySession.*`: `CreatePseudoConsole` + `CreateProcessW` with `PROC_THREAD_ATTRIBUTE_PSEUDOCONSOLE`, reader/waiter threads, resize, clean shutdown.
- **Admin tabs**: a ConPTY can't cross an integrity boundary, so a non-elevated app relaunches itself via `ShellExecuteEx("runas")` as a hidden broker that owns the ConPTY and bridges it over two randomly named, single-instance named pipes. The app only accepts a pipe client whose PID equals the broker it launched. Declining UAC prints a message in the tab. If the app is already elevated, admin tabs use the local path.
- `TerminalView.*` + `TerminalScreen.*`: WinUI surface and a deliberately small VT interpreter (cursor movement, erase, OSC titles, scrollback). **No colours yet**; swap in a real terminal renderer for full fidelity.
- `EditorViews.*`: Script Editor and Notepad tabs.
- `MainWindow.xaml(.cpp)`: Mica (`MicaBackdrop`, `BaseAlt`), title-bar extension, the **+** flyout (in `TabStripFooter`, right after the last tab), tab lifecycle.
- `App.xaml`: Fluent control resources and terminal brushes.

## Notes

- "7.6.7" comes from `kPwshVersion` in `Shells.h`; the tab prints a warning if the installed pwsh.exe differs, and launches whatever is installed.
- Keys: Ctrl+V paste, Ctrl+Shift+C copy selection, Ctrl+C goes to the shell, Ctrl+Tab switches tabs.
- Exit code 0 closes the tab; non-zero keeps it open showing the code.
