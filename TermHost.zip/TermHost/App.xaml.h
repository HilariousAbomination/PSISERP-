#pragma once
#include "App.xaml.g.h"

namespace winrt::TermHost::implementation {
struct App : AppT<App> {
    App();
    void OnLaunched(Microsoft::UI::Xaml::LaunchActivatedEventArgs const&);

private:
    winrt::Microsoft::UI::Xaml::Window m_window{nullptr};
};
}  // namespace winrt::TermHost::implementation
