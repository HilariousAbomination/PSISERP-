#include "Shells.h"

#include <windows.h>
#include <filesystem>
#include <vector>

#pragma comment(lib, "version.lib")

namespace th {

static std::wstring Env(const wchar_t* name) {
    wchar_t buf[MAX_PATH * 2];
    DWORD n = GetEnvironmentVariableW(name, buf, ARRAYSIZE(buf));
    return (n > 0 && n < ARRAYSIZE(buf)) ? std::wstring(buf, n) : std::wstring();
}

std::wstring FindPwsh() {
    std::wstring pf = Env(L"ProgramFiles");
    if (!pf.empty()) {
        auto p = std::filesystem::path(pf) / L"PowerShell" / L"7" / L"pwsh.exe";
        std::error_code ec;
        if (std::filesystem::exists(p, ec)) return p.wstring();
    }
    wchar_t found[MAX_PATH];
    if (SearchPathW(nullptr, L"pwsh.exe", nullptr, ARRAYSIZE(found), found, nullptr)) return found;
    return {};
}

std::wstring PwshFileVersion(const std::wstring& path) {
    DWORD ignored = 0;
    DWORD size = GetFileVersionInfoSizeW(path.c_str(), &ignored);
    if (!size) return {};
    std::vector<BYTE> data(size);
    if (!GetFileVersionInfoW(path.c_str(), 0, size, data.data())) return {};
    VS_FIXEDFILEINFO* fi = nullptr;
    UINT len = 0;
    if (!VerQueryValueW(data.data(), L"\\", reinterpret_cast<LPVOID*>(&fi), &len) || !fi) return {};
    return std::to_wstring(HIWORD(fi->dwFileVersionMS)) + L"." + std::to_wstring(LOWORD(fi->dwFileVersionMS)) + L"." +
           std::to_wstring(HIWORD(fi->dwFileVersionLS));
}

std::wstring FindCmd() {
    std::wstring c = Env(L"ComSpec");
    if (!c.empty()) return c;
    wchar_t sys[MAX_PATH];
    GetSystemDirectoryW(sys, ARRAYSIZE(sys));
    return (std::filesystem::path(sys) / L"cmd.exe").wstring();
}

std::wstring UserProfile() { return Env(L"USERPROFILE"); }

}  // namespace th
