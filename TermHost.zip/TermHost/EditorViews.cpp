#include "pch.h"
#include "EditorViews.h"
#include "Shells.h"
#include "Util.h"

using namespace winrt;
using namespace winrt::Microsoft::UI::Xaml;
using namespace winrt::Microsoft::UI::Xaml::Controls;
using namespace winrt::Microsoft::UI::Xaml::Controls::Primitives;
using namespace winrt::Microsoft::UI::Xaml::Media;
using namespace winrt::Windows::System;

namespace th {

static Button MakeButton(wchar_t const* glyph, wchar_t const* label) {
    Button b;
    StackPanel sp;
    sp.Orientation(Orientation::Horizontal);
    sp.Spacing(8);
    FontIcon icon;
    icon.Glyph(glyph);
    icon.FontSize(14);
    TextBlock text;
    text.Text(label);
    sp.Children().Append(icon);
    sp.Children().Append(text);
    b.Content(sp);
    return b;
}

// ============================================================================
ScriptEditorView::ScriptEditorView() {
    m_path = util::DataDir() / L"scratch.ps1";

    m_root = Grid{};
    m_root.RowSpacing(6);
    m_root.Padding(ThicknessHelper::FromLengths(8, 8, 8, 8));
    for (auto [value, type] : {std::pair<double, GridUnitType>{0, GridUnitType::Auto},
                               {2, GridUnitType::Star},
                               {1, GridUnitType::Star}}) {
        RowDefinition rd;
        rd.Height(type == GridUnitType::Auto ? GridLengthHelper::Auto() : GridLengthHelper::FromValueAndType(value, type));
        m_root.RowDefinitions().Append(rd);
    }

    // toolbar
    StackPanel bar;
    bar.Orientation(Orientation::Horizontal);
    bar.Spacing(8);

    Button run = MakeButton(L"\uE768", L"Run (F5)");
    auto res = Application::Current().Resources();
    auto accentKey = box_value(L"AccentButtonStyle");
    if (res.HasKey(accentKey)) run.Style(res.Lookup(accentKey).as<Style>());
    run.Click([this](auto&&, auto&&) { Run(); });
    KeyboardAccelerator f5;
    f5.Key(VirtualKey::F5);
    run.KeyboardAccelerators().Append(f5);
    bar.Children().Append(run);

    m_admin = ToggleButton{};
    StackPanel adminContent;
    adminContent.Orientation(Orientation::Horizontal);
    adminContent.Spacing(8);
    FontIcon shield;
    shield.Glyph(L"\uE7EF");
    shield.FontSize(14);
    TextBlock adminText;
    adminText.Text(L"Run as administrator");
    adminContent.Children().Append(shield);
    adminContent.Children().Append(adminText);
    m_admin.Content(adminContent);
    bar.Children().Append(m_admin);

    Button save = MakeButton(L"\uE74E", L"Save");
    save.Click([this](auto&&, auto&&) { Save(); });
    bar.Children().Append(save);

    Grid::SetRow(bar, 0);
    m_root.Children().Append(bar);

    // editor
    m_editor = TextBox{};
    m_editor.AcceptsReturn(true);
    m_editor.TextWrapping(TextWrapping::NoWrap);
    m_editor.IsSpellCheckEnabled(false);
    m_editor.FontFamily(FontFamily{L"Cascadia Mono, Consolas"});
    m_editor.FontSize(14);
    ScrollViewer::SetHorizontalScrollBarVisibility(m_editor, ScrollBarVisibility::Auto);
    ScrollViewer::SetVerticalScrollBarVisibility(m_editor, ScrollBarVisibility::Auto);
    std::wstring existing = util::ReadText(m_path);
    m_editor.Text(existing.empty() ? hstring{L"Write-Host \"Hello from TermHost\" -ForegroundColor Green\r\nGet-Date\r\n"}
                                   : hstring{existing});
    Grid::SetRow(m_editor, 1);
    m_root.Children().Append(m_editor);

    // output
    m_output = std::make_shared<TerminalView>();
    m_output->Print(L"Press F5 to run the script.\r\n");
    auto out = m_output->Root();
    Grid::SetRow(out, 2);
    m_root.Children().Append(out);
}

void ScriptEditorView::Save() { util::WriteText(m_path, std::wstring(m_editor.Text())); }

void ScriptEditorView::Run() {
    Save();
    std::wstring pwsh = FindPwsh();
    m_output->Clear();
    if (pwsh.empty()) {
        m_output->Print(L"PowerShell 7 (pwsh.exe) was not found.\r\n");
        return;
    }
    SessionOptions o;
    o.commandLine = L"\"" + pwsh + L"\" -NoLogo -NoProfile -ExecutionPolicy Bypass -File \"" + m_path.wstring() + L"\"";
    o.workingDirectory = m_path.parent_path().wstring();
    o.elevated = m_admin.IsChecked().Value();
    m_output->Start(o);
}

void ScriptEditorView::Close() {
    Save();
    if (m_output) m_output->Close();
}

// ============================================================================
NotepadView::NotepadView() {
    m_path = util::DataDir() / L"notepad.txt";
    m_box = TextBox{};
    m_box.AcceptsReturn(true);
    m_box.TextWrapping(TextWrapping::Wrap);
    m_box.IsSpellCheckEnabled(true);
    m_box.FontFamily(FontFamily{L"Cascadia Mono, Consolas"});
    m_box.FontSize(14);
    m_box.Margin(ThicknessHelper::FromLengths(8, 8, 8, 8));
    m_box.Text(hstring{util::ReadText(m_path)});
    m_box.LostFocus([this](auto&&, auto&&) { util::WriteText(m_path, std::wstring(m_box.Text())); });
}

void NotepadView::Close() { util::WriteText(m_path, std::wstring(m_box.Text())); }

}  // namespace th
