#pragma once
#include "ITab.h"
#include "ConPtySession.h"
#include "TerminalScreen.h"

#include <functional>
#include <memory>
#include <string>

namespace th {

// A terminal tab: ConPTY session + minimal VT screen + WinUI text surface.
// Must be created via std::make_shared (uses weak_from_this for thread hops).
class TerminalView : public ITab, public std::enable_shared_from_this<TerminalView> {
public:
    TerminalView();
    ~TerminalView() override;

    winrt::Microsoft::UI::Xaml::FrameworkElement Root() const override { return m_root; }
    void Focus() override;
    void Close() override;

    HRESULT Start(SessionOptions options);   // (re)start; prints an error in the view on failure
    void Clear();
    void Print(std::wstring_view text);      // inject local text (messages, warnings)

    void SetTitleHandler(std::function<void(std::wstring)> f) { m_onTitle = std::move(f); }
    // Called (UI thread) when the child exits with code 0.
    void SetCloseRequestedHandler(std::function<void()> f) { m_onCloseRequested = std::move(f); }

private:
    void OnOutput(const std::string& bytes);
    void OnExit(DWORD code);
    void Flush();
    void OnKeyDown(winrt::Microsoft::UI::Xaml::Input::KeyRoutedEventArgs const& e);
    void OnChar(winrt::Microsoft::UI::Xaml::Input::CharacterReceivedRoutedEventArgs const& e);
    void Send(std::wstring_view text);
    void Paste();
    void CopySelection();
    void MeasureCell();
    void UpdateGridSize();

    winrt::Microsoft::UI::Xaml::Controls::ContentControl m_root{nullptr};
    winrt::Microsoft::UI::Xaml::Controls::ScrollViewer m_scroll{nullptr};
    winrt::Microsoft::UI::Xaml::Controls::TextBlock m_text{nullptr};
    winrt::Microsoft::UI::Dispatching::DispatcherQueue m_dispatcher{nullptr};
    winrt::Microsoft::UI::Dispatching::DispatcherQueueTimer m_timer{nullptr};

    std::unique_ptr<ConPtySession> m_session;
    TerminalScreen m_screen;
    std::string m_pending;           // incomplete UTF-8 tail between reads
    wchar_t m_highSurrogate = 0;

    int m_cols = 120, m_rows = 30;
    double m_cellW = 0, m_cellH = 0;
    bool m_dirty = false, m_cursorOn = true, m_exited = false;
    int m_tick = 0;

    std::function<void(std::wstring)> m_onTitle;
    std::function<void()> m_onCloseRequested;
};

}  // namespace th
