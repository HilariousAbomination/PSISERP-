#include "ConPtySession.h"

#include <shellapi.h>
#include <objbase.h>
#include <algorithm>
#include <cstdint>
#include <cstring>
#include <vector>

#pragma comment(lib, "shell32.lib")
#pragma comment(lib, "ole32.lib")

namespace th {
namespace {

// ---- tiny framed protocol used on the broker pipes -------------------------
//  [type:1][len:4 LE][payload]
//  app -> broker : 'D' input bytes, 'R' resize (short cols, short rows), 'Q' quit
//  broker -> app : 'D' output bytes, 'X' child exited (DWORD code)

bool WriteAll(HANDLE h, const void* p, size_t n) {
    auto b = static_cast<const BYTE*>(p);
    while (n) {
        DWORD w = 0;
        DWORD chunk = static_cast<DWORD>((std::min)(n, size_t(1) << 20));
        if (!WriteFile(h, b, chunk, &w, nullptr) || w == 0) return false;
        b += w;
        n -= w;
    }
    return true;
}

bool ReadAll(HANDLE h, void* p, size_t n) {
    auto b = static_cast<BYTE*>(p);
    while (n) {
        DWORD r = 0;
        DWORD chunk = static_cast<DWORD>((std::min)(n, size_t(1) << 20));
        if (!ReadFile(h, b, chunk, &r, nullptr) || r == 0) return false;
        b += r;
        n -= r;
    }
    return true;
}

bool WriteFrame(HANDLE h, char type, const void* data, uint32_t len) {
    BYTE hdr[5] = {static_cast<BYTE>(type), static_cast<BYTE>(len), static_cast<BYTE>(len >> 8),
                   static_cast<BYTE>(len >> 16), static_cast<BYTE>(len >> 24)};
    return WriteAll(h, hdr, sizeof hdr) && (len == 0 || WriteAll(h, data, len));
}

bool ReadFrame(HANDLE h, char& type, std::string& payload) {
    BYTE hdr[5];
    if (!ReadAll(h, hdr, sizeof hdr)) return false;
    type = static_cast<char>(hdr[0]);
    uint32_t len = hdr[1] | (hdr[2] << 8) | (hdr[3] << 16) | (static_cast<uint32_t>(hdr[4]) << 24);
    if (len > (1u << 24)) return false;
    payload.resize(len);
    return len == 0 || ReadAll(h, payload.data(), len);
}

// Quote one argument so CommandLineToArgvW round-trips it.
std::wstring QuoteArg(const std::wstring& arg) {
    std::wstring out = L"\"";
    size_t backslashes = 0;
    for (wchar_t c : arg) {
        if (c == L'\\') { ++backslashes; continue; }
        if (c == L'"') {
            out.append(backslashes * 2 + 1, L'\\');
            out.push_back(L'"');
        } else {
            out.append(backslashes, L'\\');
            out.push_back(c);
        }
        backslashes = 0;
    }
    out.append(backslashes * 2, L'\\');
    out.push_back(L'"');
    return out;
}

}  // namespace

bool IsProcessElevated() {
    HANDLE token = nullptr;
    if (!OpenProcessToken(GetCurrentProcess(), TOKEN_QUERY, &token)) return false;
    TOKEN_ELEVATION e{};
    DWORD size = 0;
    bool result = GetTokenInformation(token, TokenElevation, &e, sizeof e, &size) && e.TokenIsElevated;
    CloseHandle(token);
    return result;
}

// ============================================================================
// ConPtySession
// ============================================================================

HRESULT ConPtySession::Start(const SessionOptions& o, OutputHandler onOutput, ExitHandler onExit) {
    m_onOutput = std::move(onOutput);
    m_onExit = std::move(onExit);
    m_closing = false;
    if (o.elevated && !IsProcessElevated()) return StartBrokered(o);
    return StartLocal(o);
}

HRESULT ConPtySession::StartLocal(const SessionOptions& o) {
    HANDLE inRead = nullptr, inWrite = nullptr, outRead = nullptr, outWrite = nullptr;
    if (!CreatePipe(&inRead, &inWrite, nullptr, 0)) return HRESULT_FROM_WIN32(GetLastError());
    if (!CreatePipe(&outRead, &outWrite, nullptr, 0)) {
        DWORD e = GetLastError();
        CloseHandle(inRead); CloseHandle(inWrite);
        return HRESULT_FROM_WIN32(e);
    }

    HRESULT hr = CreatePseudoConsole(COORD{o.cols, o.rows}, inRead, outWrite, 0, &m_hpc);
    // The pseudo console now owns its ends of the pipes.
    CloseHandle(inRead);
    CloseHandle(outWrite);
    if (FAILED(hr)) {
        CloseHandle(inWrite); CloseHandle(outRead);
        m_hpc = nullptr;
        return hr;
    }

    STARTUPINFOEXW si{};
    si.StartupInfo.cb = sizeof si;
    SIZE_T bytes = 0;
    InitializeProcThreadAttributeList(nullptr, 1, 0, &bytes);
    std::vector<BYTE> attrBuf(bytes);
    si.lpAttributeList = reinterpret_cast<PPROC_THREAD_ATTRIBUTE_LIST>(attrBuf.data());
    if (!InitializeProcThreadAttributeList(si.lpAttributeList, 1, 0, &bytes) ||
        !UpdateProcThreadAttribute(si.lpAttributeList, 0, PROC_THREAD_ATTRIBUTE_PSEUDOCONSOLE, m_hpc,
                                   sizeof(HPCON), nullptr, nullptr)) {
        hr = HRESULT_FROM_WIN32(GetLastError());
        CloseConsole();
        CloseHandle(inWrite); CloseHandle(outRead);
        return hr;
    }

    std::wstring cmd = o.commandLine;  // CreateProcessW needs a mutable buffer
    PROCESS_INFORMATION pi{};
    BOOL ok = CreateProcessW(nullptr, cmd.data(), nullptr, nullptr, FALSE,
                             EXTENDED_STARTUPINFO_PRESENT | CREATE_UNICODE_ENVIRONMENT, nullptr,
                             o.workingDirectory.empty() ? nullptr : o.workingDirectory.c_str(),
                             &si.StartupInfo, &pi);
    DWORD createErr = ok ? 0 : GetLastError();
    DeleteProcThreadAttributeList(si.lpAttributeList);
    if (!ok) {
        CloseConsole();
        CloseHandle(inWrite); CloseHandle(outRead);
        return HRESULT_FROM_WIN32(createErr);
    }

    CloseHandle(pi.hThread);
    m_process = pi.hProcess;
    m_in = inWrite;
    m_out = outRead;
    m_reader = std::thread(&ConPtySession::LocalReadLoop, this);
    m_waiter = std::thread(&ConPtySession::LocalWaitLoop, this);
    return S_OK;
}

void ConPtySession::CloseConsole() {
    static_assert(sizeof(HPCON) == sizeof(void*));
    auto hpc = reinterpret_cast<HPCON>(InterlockedExchangePointer(reinterpret_cast<PVOID*>(&m_hpc), nullptr));
    if (hpc) ClosePseudoConsole(hpc);  // flushes remaining output; reader must keep draining
}

// The output pipe only reaches EOF after ClosePseudoConsole, so a separate
// waiter notices child exit, records the code, then closes the console.
void ConPtySession::LocalWaitLoop() {
    WaitForSingleObject(m_process, INFINITE);
    DWORD code = 0;
    GetExitCodeProcess(m_process, &code);
    m_exitCode = code;
    CloseConsole();
}

void ConPtySession::LocalReadLoop() {
    char buf[8192];
    DWORD n = 0;
    while (ReadFile(m_out, buf, sizeof buf, &n, nullptr) && n > 0) {
        if (m_closing) return;
        m_onOutput(std::string_view(buf, n));
    }
    if (!m_closing && m_onExit) m_onExit(m_exitCode);
}

HRESULT ConPtySession::StartBrokered(const SessionOptions& o) {
    GUID g{};
    CoCreateGuid(&g);
    wchar_t gs[64]{};
    StringFromGUID2(g, gs, 64);
    std::wstring base = std::wstring(L"\\\\.\\pipe\\TermHost.") + gs;

    const DWORD mode = PIPE_TYPE_BYTE | PIPE_READMODE_BYTE | PIPE_WAIT | PIPE_REJECT_REMOTE_CLIENTS;
    m_pipeWrite = CreateNamedPipeW((base + L".in").c_str(), PIPE_ACCESS_OUTBOUND | FILE_FLAG_FIRST_PIPE_INSTANCE,
                                   mode, 1, 65536, 65536, 0, nullptr);
    m_pipeRead = CreateNamedPipeW((base + L".out").c_str(), PIPE_ACCESS_INBOUND | FILE_FLAG_FIRST_PIPE_INSTANCE,
                                  mode, 1, 65536, 65536, 0, nullptr);
    if (m_pipeWrite == INVALID_HANDLE_VALUE || m_pipeRead == INVALID_HANDLE_VALUE) {
        DWORD e = GetLastError();
        if (m_pipeWrite != INVALID_HANDLE_VALUE) CloseHandle(m_pipeWrite);
        if (m_pipeRead != INVALID_HANDLE_VALUE) CloseHandle(m_pipeRead);
        m_pipeWrite = m_pipeRead = INVALID_HANDLE_VALUE;
        return HRESULT_FROM_WIN32(e);
    }

    wchar_t exe[MAX_PATH]{};
    GetModuleFileNameW(nullptr, exe, MAX_PATH);
    std::wstring params = L"--broker " + QuoteArg(base) + L" " + std::to_wstring(o.cols) + L" " +
                          std::to_wstring(o.rows) + L" " + QuoteArg(o.workingDirectory) + L" " +
                          QuoteArg(o.commandLine);

    SHELLEXECUTEINFOW sei{sizeof sei};
    sei.fMask = SEE_MASK_NOCLOSEPROCESS | SEE_MASK_NOASYNC;
    sei.lpVerb = L"runas";  // UAC prompt
    sei.lpFile = exe;
    sei.lpParameters = params.c_str();
    sei.nShow = SW_HIDE;
    if (!ShellExecuteExW(&sei)) {
        DWORD e = GetLastError();  // ERROR_CANCELLED (1223) if the user declined UAC
        CloseHandle(m_pipeWrite); CloseHandle(m_pipeRead);
        m_pipeWrite = m_pipeRead = INVALID_HANDLE_VALUE;
        return HRESULT_FROM_WIN32(e);
    }

    m_brokered = true;
    m_process = sei.hProcess;
    DWORD pid = GetProcessId(sei.hProcess);
    m_reader = std::thread([this, pid] { BrokerReadLoop(pid); });
    return S_OK;
}

void ConPtySession::BrokerReadLoop(DWORD brokerPid) {
    // Accept only the process we launched (guards against pipe squatting).
    auto accept = [&](HANDLE pipe) {
        if (!ConnectNamedPipe(pipe, nullptr) && GetLastError() != ERROR_PIPE_CONNECTED) return false;
        ULONG pid = 0;
        return GetNamedPipeClientProcessId(pipe, &pid) && pid == brokerPid;
    };
    if (!accept(m_pipeWrite) || !accept(m_pipeRead)) {
        if (!m_closing && m_onExit) m_onExit(0xFFFFFFFF);
        return;
    }
    m_connected = true;

    char type = 0;
    std::string payload;
    while (ReadFrame(m_pipeRead, type, payload)) {
        if (type == 'D') {
            m_onOutput(payload);
        } else if (type == 'X' && payload.size() == 4) {
            DWORD code = 0;
            std::memcpy(&code, payload.data(), 4);
            if (!m_closing && m_onExit) m_onExit(code);
            return;
        }
    }
    if (!m_closing && m_onExit) m_onExit(0xFFFFFFFF);
}

void ConPtySession::Write(std::string_view s) {
    if (s.empty()) return;
    std::lock_guard<std::mutex> lock(m_writeLock);
    if (m_brokered) {
        if (m_connected) WriteFrame(m_pipeWrite, 'D', s.data(), static_cast<uint32_t>(s.size()));
    } else if (m_in) {
        WriteAll(m_in, s.data(), s.size());
    }
}

void ConPtySession::Resize(short cols, short rows) {
    if (m_brokered) {
        if (!m_connected) return;
        short dims[2] = {cols, rows};
        std::lock_guard<std::mutex> lock(m_writeLock);
        WriteFrame(m_pipeWrite, 'R', dims, sizeof dims);
    } else if (m_hpc) {
        ResizePseudoConsole(m_hpc, COORD{cols, rows});
    }
}

void ConPtySession::Close() {
    if (m_closing.exchange(true)) return;

    if (m_brokered) {
        if (m_connected) {
            std::lock_guard<std::mutex> lock(m_writeLock);
            WriteFrame(m_pipeWrite, 'Q', nullptr, 0);
        }
        if (m_pipeWrite != INVALID_HANDLE_VALUE) CancelIoEx(m_pipeWrite, nullptr);
        if (m_pipeRead != INVALID_HANDLE_VALUE) CancelIoEx(m_pipeRead, nullptr);
        if (m_reader.joinable()) m_reader.join();
        if (m_pipeWrite != INVALID_HANDLE_VALUE) CloseHandle(m_pipeWrite);
        if (m_pipeRead != INVALID_HANDLE_VALUE) CloseHandle(m_pipeRead);
        m_pipeWrite = m_pipeRead = INVALID_HANDLE_VALUE;
        if (m_process) { CloseHandle(m_process); m_process = nullptr; }  // broker exits on pipe EOF
        return;
    }

    if (m_process) TerminateProcess(m_process, 1);
    CloseConsole();
    if (m_waiter.joinable()) m_waiter.join();
    if (m_reader.joinable()) m_reader.join();
    if (m_in) { CloseHandle(m_in); m_in = nullptr; }
    if (m_out) { CloseHandle(m_out); m_out = nullptr; }
    if (m_process) { CloseHandle(m_process); m_process = nullptr; }
}

// ============================================================================
// Elevated broker (runs in the UAC-elevated copy of the exe, no UI)
// ============================================================================

int RunElevatedBroker(int argc, wchar_t** argv) {
    if (argc < 7 || !IsProcessElevated()) return 3;  // only meaningful when elevated

    std::wstring base = argv[2];
    SessionOptions o;
    o.cols = static_cast<short>(_wtoi(argv[3]));
    o.rows = static_cast<short>(_wtoi(argv[4]));
    o.workingDirectory = argv[5];
    o.commandLine = argv[6];

    HANDLE hCtl = CreateFileW((base + L".in").c_str(), GENERIC_READ, 0, nullptr, OPEN_EXISTING, 0, nullptr);
    HANDLE hOut = CreateFileW((base + L".out").c_str(), GENERIC_WRITE, 0, nullptr, OPEN_EXISTING, 0, nullptr);
    if (hCtl == INVALID_HANDLE_VALUE || hOut == INVALID_HANDLE_VALUE) return 2;

    std::mutex outLock;
    ConPtySession session;
    HRESULT hr = session.Start(
        o,
        [&](std::string_view d) {
            std::lock_guard<std::mutex> l(outLock);
            WriteFrame(hOut, 'D', d.data(), static_cast<uint32_t>(d.size()));
        },
        [&](DWORD code) {
            std::lock_guard<std::mutex> l(outLock);
            WriteFrame(hOut, 'X', &code, sizeof code);
        });
    if (FAILED(hr)) {
        DWORD code = static_cast<DWORD>(hr);
        std::lock_guard<std::mutex> l(outLock);
        WriteFrame(hOut, 'X', &code, sizeof code);
        return 1;
    }

    char type = 0;
    std::string payload;
    while (ReadFrame(hCtl, type, payload)) {
        if (type == 'D') {
            session.Write(payload);
        } else if (type == 'R' && payload.size() == 4) {
            short dims[2];
            std::memcpy(dims, payload.data(), 4);
            session.Resize(dims[0], dims[1]);
        } else if (type == 'Q') {
            break;
        }
    }
    session.Close();
    CloseHandle(hCtl);
    CloseHandle(hOut);
    return 0;
}

}  // namespace th
