#pragma once
#include "ITab.h"
#include "TerminalView.h"

#include <filesystem>
#include <memory>

namespace th {

// Script workspace: PowerShell editor on top, live ConPTY output pane below.
// Run (F5) saves the buffer to %LOCALAPPDATA%\TermHost\scratch.ps1 and runs it
// with the installed pwsh; the "Admin" toggle runs it elevated via the broker.
class ScriptEditorView : public ITab {
public:
    ScriptEditorView();
    winrt::Microsoft::UI::Xaml::FrameworkElement Root() const override { return m_root; }
    void Focus() override { m_editor.Focus(winrt::Microsoft::UI::Xaml::FocusState::Programmatic); }
    void Close() override;

private:
    void Run();
    void Save();

    winrt::Microsoft::UI::Xaml::Controls::Grid m_root{nullptr};
    winrt::Microsoft::UI::Xaml::Controls::TextBox m_editor{nullptr};
    winrt::Microsoft::UI::Xaml::Controls::Primitives::ToggleButton m_admin{nullptr};
    std::shared_ptr<TerminalView> m_output;
    std::filesystem::path m_path;
};

// Plain scratchpad persisted to %LOCALAPPDATA%\TermHost\notepad.txt.
class NotepadView : public ITab {
public:
    NotepadView();
    winrt::Microsoft::UI::Xaml::FrameworkElement Root() const override { return m_box; }
    void Focus() override { m_box.Focus(winrt::Microsoft::UI::Xaml::FocusState::Programmatic); }
    void Close() override;

private:
    winrt::Microsoft::UI::Xaml::Controls::TextBox m_box{nullptr};
    std::filesystem::path m_path;
};

}  // namespace th
