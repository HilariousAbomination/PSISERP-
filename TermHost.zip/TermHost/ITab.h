#pragma once
#include "pch.h"

namespace th {

// Anything that can live inside a TabViewItem.
struct ITab {
    virtual ~ITab() = default;
    virtual winrt::Microsoft::UI::Xaml::FrameworkElement Root() const = 0;
    virtual void Focus() = 0;
    virtual void Close() = 0;  // stop sessions, flush files
};

}  // namespace th
