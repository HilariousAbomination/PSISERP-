#pragma once
#include <windows.h>
#include <atomic>
#include <functional>
#include <mutex>
#include <string>
#include <string_view>
#include <thread>

namespace th {

struct SessionOptions {
    std::wstring commandLine;        // full command line, e.g. "C:\...\pwsh.exe" -NoLogo
    std::wstring workingDirectory;   // may be empty
    short cols = 120;
    short rows = 30;
    bool elevated = false;           // request an Administrator session
};

bool IsProcessElevated();

// Entry point used when the exe is relaunched elevated with:
//   --broker <pipeBase> <cols> <rows> <cwd> <cmdline>
int RunElevatedBroker(int argc, wchar_t** argv);

// Hosts one console child process behind a pseudo console (ConPTY).
//
//  * Non-elevated request (or app already elevated): the child is created
//    directly on a ConPTY owned by this process.
//  * Elevated request from a non-elevated app: a UAC-elevated copy of this exe
//    ("broker") owns the ConPTY and bridges it to us over two named pipes.
//    A ConPTY can't be handed across an integrity boundary, hence the broker.
//
// Callbacks fire on background threads.
class ConPtySession {
public:
    using OutputHandler = std::function<void(std::string_view)>;  // raw UTF-8 / VT bytes
    using ExitHandler = std::function<void(DWORD)>;

    ConPtySession() = default;
    ConPtySession(const ConPtySession&) = delete;
    ConPtySession& operator=(const ConPtySession&) = delete;
    ~ConPtySession() { Close(); }

    HRESULT Start(const SessionOptions& options, OutputHandler onOutput, ExitHandler onExit);
    void Write(std::string_view utf8);
    void Resize(short cols, short rows);
    void Close();

private:
    HRESULT StartLocal(const SessionOptions& options);
    HRESULT StartBrokered(const SessionOptions& options);
    void LocalReadLoop();
    void LocalWaitLoop();
    void BrokerReadLoop(DWORD brokerPid);
    void CloseConsole();

    OutputHandler m_onOutput;
    ExitHandler m_onExit;

    // local mode
    HPCON m_hpc = nullptr;
    HANDLE m_in = nullptr;        // we write -> child stdin
    HANDLE m_out = nullptr;       // we read  <- child stdout
    HANDLE m_process = nullptr;
    std::atomic<DWORD> m_exitCode{0};

    // brokered mode
    bool m_brokered = false;
    HANDLE m_pipeWrite = INVALID_HANDLE_VALUE;  // app -> broker
    HANDLE m_pipeRead = INVALID_HANDLE_VALUE;   // broker -> app
    std::atomic<bool> m_connected{false};

    std::atomic<bool> m_closing{false};
    std::thread m_reader;
    std::thread m_waiter;
    std::mutex m_writeLock;
};

}  // namespace th
