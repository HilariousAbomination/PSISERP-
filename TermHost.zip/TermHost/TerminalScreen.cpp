#include "TerminalScreen.h"

#include <algorithm>

namespace th {

void TerminalScreen::Reset() {
    m_lines.assign(1, std::wstring());
    m_row = m_col = m_viewTop = 0;
    m_state = State::Ground;
    m_param.clear();
    m_osc.clear();
}

void TerminalScreen::EnsureRow(size_t r) {
    if (m_lines.size() <= r) m_lines.resize(r + 1);
}

void TerminalScreen::Put(wchar_t c) {
    if (m_col >= static_cast<size_t>(m_cols)) {  // auto-wrap
        m_col = 0;
        LineFeed();
    }
    EnsureRow(m_row);
    auto& line = m_lines[m_row];
    if (line.size() < m_col) line.resize(m_col, L' ');
    if (m_col < line.size()) line[m_col] = c; else line.push_back(c);
    ++m_col;
}

void TerminalScreen::LineFeed() {
    ++m_row;
    EnsureRow(m_row);
    if (m_row >= m_viewTop + static_cast<size_t>(m_rows)) m_viewTop = m_row + 1 - m_rows;
    if (m_lines.size() > kMaxLines) {
        m_lines.erase(m_lines.begin(), m_lines.begin() + kTrimLines);
        m_row = m_row > kTrimLines ? m_row - kTrimLines : 0;
        m_viewTop = m_viewTop > kTrimLines ? m_viewTop - kTrimLines : 0;
    }
}

void TerminalScreen::Feed(std::wstring_view text) {
    for (wchar_t c : text) {
        switch (m_state) {
        case State::Ground:
            switch (c) {
            case 0x1B: m_state = State::Esc; break;
            case L'\r': m_col = 0; break;
            case L'\n': LineFeed(); break;
            case L'\b': if (m_col > 0) --m_col; break;
            case L'\t': m_col = ((m_col / 8) + 1) * 8; break;
            case 7: break;
            default: if (c >= 0x20) Put(c);
            }
            break;
        case State::Esc:
            if (c == L'[') { m_state = State::Csi; m_param.clear(); }
            else if (c == L']' || c == L'P' || c == L'_' || c == L'^' || c == L'X') { m_state = State::Osc; m_osc.clear(); }
            else if (c == L'(' || c == L')' || c == L'#' || c == L'%' || c == L' ') m_state = State::EscSkip;
            else {
                if (c == L'M' && m_row > m_viewTop) --m_row;  // reverse index
                m_state = State::Ground;
            }
            break;
        case State::EscSkip: m_state = State::Ground; break;
        case State::Csi:
            if (c >= 0x40 && c <= 0x7E) { ExecCsi(c); m_state = State::Ground; }
            else m_param.push_back(c);
            break;
        case State::Osc:
            if (c == 7) { EndOsc(); m_state = State::Ground; }
            else if (c == 0x1B) m_state = State::OscEsc;
            else m_osc.push_back(c);
            break;
        case State::OscEsc:
            EndOsc();
            m_state = State::Ground;
            break;
        }
    }
}

void TerminalScreen::EndOsc() {
    if (m_osc.size() > 2 && (m_osc.rfind(L"0;", 0) == 0 || m_osc.rfind(L"2;", 0) == 0)) {
        m_title = m_osc.substr(2);
        m_titleDirty = true;
    }
    m_osc.clear();
}

bool TerminalScreen::TakeTitle(std::wstring& title) {
    if (!m_titleDirty) return false;
    m_titleDirty = false;
    title = m_title;
    return true;
}

void TerminalScreen::ExecCsi(wchar_t fin) {
    if (!m_param.empty() && (m_param[0] == L'?' || m_param[0] == L'>' || m_param[0] == L'=' || m_param[0] == L'<'))
        return;  // private modes: ignored

    std::vector<int> p;
    {
        int v = -1;
        for (wchar_t c : m_param) {
            if (c >= L'0' && c <= L'9') v = (v < 0 ? 0 : v) * 10 + (c - L'0');
            else if (c == L';' || c == L':') { p.push_back(v); v = -1; }
            else return;  // intermediate bytes (e.g. cursor style): ignored
        }
        p.push_back(v);
    }
    auto arg = [&](size_t i, int def) { return (i < p.size() && p[i] > 0) ? p[i] : def; };
    const size_t viewBottom = m_viewTop + m_rows - 1;

    switch (fin) {
    case L'A': m_row = (std::max)(m_viewTop, m_row - (std::min)(m_row, static_cast<size_t>(arg(0, 1)))); break;
    case L'B': m_row = (std::min)(viewBottom, m_row + arg(0, 1)); EnsureRow(m_row); break;
    case L'C': m_col = (std::min)(static_cast<size_t>(m_cols - 1), m_col + arg(0, 1)); break;
    case L'D': m_col = m_col > static_cast<size_t>(arg(0, 1)) ? m_col - arg(0, 1) : 0; break;
    case L'G': m_col = arg(0, 1) - 1; break;
    case L'd': m_row = (std::min)(viewBottom, m_viewTop + arg(0, 1) - 1); EnsureRow(m_row); break;
    case L'H':
    case L'f':
        m_row = (std::min)(viewBottom, m_viewTop + arg(0, 1) - 1);
        m_col = arg(1, 1) - 1;
        EnsureRow(m_row);
        break;
    case L'K': {
        int mode = (!p.empty() && p[0] > 0) ? p[0] : 0;
        EnsureRow(m_row);
        auto& l = m_lines[m_row];
        if (mode == 0) { if (m_col < l.size()) l.erase(m_col); }
        else if (mode == 1) { for (size_t i = 0; i <= m_col && i < l.size(); ++i) l[i] = L' '; }
        else l.clear();
        break;
    }
    case L'J': {
        int mode = (!p.empty() && p[0] > 0) ? p[0] : 0;
        EnsureRow(m_row);
        if (mode == 0) {
            auto& l = m_lines[m_row];
            if (m_col < l.size()) l.erase(m_col);
            for (size_t r = m_row + 1; r < m_lines.size(); ++r) m_lines[r].clear();
        } else if (mode == 1) {
            for (size_t r = m_viewTop; r < m_row; ++r) m_lines[r].clear();
            auto& l = m_lines[m_row];
            for (size_t i = 0; i <= m_col && i < l.size(); ++i) l[i] = L' ';
        } else if (mode == 2) {
            for (size_t r = m_viewTop; r < m_lines.size(); ++r) m_lines[r].clear();
        } else if (mode == 3) {  // clear scrollback, keep the viewport
            m_lines.erase(m_lines.begin(), m_lines.begin() + m_viewTop);
            m_row -= m_viewTop;
            m_viewTop = 0;
        }
        break;
    }
    case L'X': {
        EnsureRow(m_row);
        auto& l = m_lines[m_row];
        for (size_t i = m_col; i < m_col + arg(0, 1) && i < l.size(); ++i) l[i] = L' ';
        break;
    }
    case L'P': {
        EnsureRow(m_row);
        auto& l = m_lines[m_row];
        if (m_col < l.size()) l.erase(m_col, (std::min)(l.size() - m_col, static_cast<size_t>(arg(0, 1))));
        break;
    }
    case L'@': {
        EnsureRow(m_row);
        auto& l = m_lines[m_row];
        if (m_col < l.size()) l.insert(m_col, static_cast<size_t>(arg(0, 1)), L' ');
        break;
    }
    default: break;  // SGR ('m'), modes, scroll regions... ignored
    }
}

std::wstring TerminalScreen::Render(bool showCursor) const {
    size_t last = m_row;
    for (size_t i = m_lines.size(); i-- > m_row + 1;) {
        if (!m_lines[i].empty()) { last = i; break; }
    }
    std::wstring out;
    out.reserve(last * 40);
    for (size_t i = 0; i <= last && i < m_lines.size(); ++i) {
        std::wstring line = m_lines[i];
        if (i == m_row && showCursor) {
            if (line.size() < m_col) line.resize(m_col, L' ');
            if (m_col < line.size()) line[m_col] = L'\u2588'; else line.push_back(L'\u2588');
        } else {
            while (!line.empty() && line.back() == L' ') line.pop_back();
        }
        out += line;
        if (i < last) out += L'\n';
    }
    return out;
}

}  // namespace th
