#pragma once
#include <string>
#include <string_view>
#include <vector>

namespace th {

// Deliberately small VT interpreter: enough for cmd.exe / pwsh through ConPTY
// to be usable (cursor movement, line/screen erase, OSC titles). It keeps a
// scrollback of plain text lines and does NOT render colours/SGR yet.
// Replace it with a real terminal renderer (e.g. a Win2D/DirectWrite cell grid
// or Microsoft's terminal control) when you need full fidelity.
class TerminalScreen {
public:
    TerminalScreen() { m_lines.emplace_back(); }

    void Resize(int cols, int rows) { m_cols = cols; m_rows = rows; }
    void Reset();
    void Feed(std::wstring_view text);
    std::wstring Render(bool showCursor) const;

    // Returns true (once) if an OSC 0/2 title arrived since the last call.
    bool TakeTitle(std::wstring& title);

private:
    enum class State { Ground, Esc, EscSkip, Csi, Osc, OscEsc };

    void Put(wchar_t c);
    void LineFeed();
    void EnsureRow(size_t r);
    void ExecCsi(wchar_t final);
    void EndOsc();

    static constexpr size_t kMaxLines = 10000;
    static constexpr size_t kTrimLines = 2000;

    std::vector<std::wstring> m_lines;
    size_t m_row = 0, m_col = 0, m_viewTop = 0;
    int m_cols = 120, m_rows = 30;

    State m_state = State::Ground;
    std::wstring m_param, m_osc, m_title;
    bool m_titleDirty = false;
};

}  // namespace th
