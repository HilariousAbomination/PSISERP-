#include "pch.h"
#include "TerminalView.h"
#include "Util.h"

#include <winrt/Windows.ApplicationModel.DataTransfer.h>

using namespace winrt;
using namespace winrt::Microsoft::UI::Xaml;
using namespace winrt::Microsoft::UI::Xaml::Controls;
using namespace winrt::Microsoft::UI::Xaml::Input;
using namespace winrt::Microsoft::UI::Xaml::Media;
using namespace winrt::Windows::System;
using namespace winrt::Windows::ApplicationModel::DataTransfer;
using namespace std::chrono_literals;

namespace th {

TerminalView::TerminalView() {
    m_dispatcher = winrt::Microsoft::UI::Dispatching::DispatcherQueue::GetForCurrentThread();

    m_text = TextBlock{};
    m_text.FontFamily(FontFamily{L"Cascadia Mono, Consolas"});
    m_text.FontSize(14);
    m_text.TextWrapping(TextWrapping::NoWrap);
    m_text.IsTextSelectionEnabled(true);

    m_scroll = ScrollViewer{};
    m_scroll.Content(m_text);
    m_scroll.Padding(ThicknessHelper::FromLengths(8, 6, 8, 6));
    m_scroll.VerticalScrollBarVisibility(ScrollBarVisibility::Auto);
    m_scroll.HorizontalScrollBarVisibility(ScrollBarVisibility::Auto);

    m_root = ContentControl{};
    m_root.IsTabStop(true);
    m_root.HorizontalContentAlignment(HorizontalAlignment::Stretch);
    m_root.VerticalContentAlignment(VerticalAlignment::Stretch);
    m_root.Content(m_scroll);

    // Styling comes from App.xaml resources so it can be re-themed without code changes.
    auto res = Application::Current().Resources();
    auto lookup = [&](wchar_t const* key) -> Brush {
        auto k = box_value(key);
        return res.HasKey(k) ? res.Lookup(k).as<Brush>() : nullptr;
    };
    if (auto bg = lookup(L"TerminalBackgroundBrush")) m_root.Background(bg);
    if (auto fg = lookup(L"TerminalForegroundBrush")) m_text.Foreground(fg);

    MeasureCell();
    m_screen.Resize(m_cols, m_rows);

    m_root.KeyDown([this](auto&&, KeyRoutedEventArgs const& e) { OnKeyDown(e); });
    m_root.CharacterReceived([this](auto&&, CharacterReceivedRoutedEventArgs const& e) { OnChar(e); });
    m_root.SizeChanged([this](auto&&, auto&&) { UpdateGridSize(); });
    // handledEventsToo = true: TextBlock selection marks pointer events handled.
    m_root.AddHandler(UIElement::PointerPressedEvent(),
                      box_value(PointerEventHandler([this](auto&&, auto&&) { m_root.Focus(FocusState::Pointer); })),
                      true);

    auto weak = weak_from_this();  // empty here (ctor); timer uses raw this, stopped in Close()
    m_timer = m_dispatcher.CreateTimer();
    m_timer.Interval(33ms);
    m_timer.Tick([this](auto&&, auto&&) {
        if (++m_tick % 15 == 0) { m_cursorOn = !m_cursorOn; m_dirty = true; }
        Flush();
    });
    m_timer.Start();
}

TerminalView::~TerminalView() { Close(); }

void TerminalView::Focus() { m_root.Focus(FocusState::Programmatic); }

void TerminalView::Close() {
    if (m_timer) { m_timer.Stop(); m_timer = nullptr; }
    m_session.reset();  // joins ConPTY threads, kills the child
    m_onTitle = nullptr;
    m_onCloseRequested = nullptr;
}

void TerminalView::MeasureCell() {
    TextBlock probe;
    probe.FontFamily(m_text.FontFamily());
    probe.FontSize(m_text.FontSize());
    probe.Text(L"MMMMMMMMMMMMMMMMMMMM");  // 20 cells
    constexpr float inf = std::numeric_limits<float>::infinity();
    probe.Measure(winrt::Windows::Foundation::Size{inf, inf});
    auto d = probe.DesiredSize();
    m_cellW = d.Width / 20.0;
    m_cellH = d.Height;
}

void TerminalView::UpdateGridSize() {
    if (m_cellW <= 0 || m_cellH <= 0) return;
    double w = m_root.ActualWidth() - 16 - 14;  // padding + scrollbar
    double h = m_root.ActualHeight() - 12;
    if (w <= 0 || h <= 0) return;
    int cols = (std::max)(20, static_cast<int>(w / m_cellW));
    int rows = (std::max)(5, static_cast<int>(h / m_cellH));
    if (cols == m_cols && rows == m_rows) return;
    m_cols = cols;
    m_rows = rows;
    m_screen.Resize(cols, rows);
    if (m_session) m_session->Resize(static_cast<short>(cols), static_cast<short>(rows));
}

HRESULT TerminalView::Start(SessionOptions options) {
    m_session.reset();
    m_pending.clear();
    m_exited = false;
    options.cols = static_cast<short>(m_cols);
    options.rows = static_cast<short>(m_rows);

    auto weak = weak_from_this();
    auto disp = m_dispatcher;
    m_session = std::make_unique<ConPtySession>();
    HRESULT hr = m_session->Start(
        options,
        [weak, disp](std::string_view d) {  // background thread
            std::string copy(d);
            disp.TryEnqueue([weak, copy] { if (auto s = weak.lock()) s->OnOutput(copy); });
        },
        [weak, disp](DWORD code) {
            disp.TryEnqueue([weak, code] { if (auto s = weak.lock()) s->OnExit(code); });
        });

    if (FAILED(hr)) {
        m_session.reset();
        std::wstring msg = hr == HRESULT_FROM_WIN32(ERROR_CANCELLED)
                               ? L"[TermHost] The elevation request was cancelled.\r\n"
                               : L"[TermHost] Failed to start session (HRESULT 0x" +
                                     [&] { wchar_t b[16]; swprintf_s(b, L"%08X", static_cast<unsigned>(hr)); return std::wstring(b); }() +
                                     L").\r\n";
        Print(msg);
    }
    return hr;
}

void TerminalView::Clear() {
    m_screen.Reset();
    m_dirty = true;
}

void TerminalView::Print(std::wstring_view text) {
    m_screen.Feed(text);
    m_dirty = true;
}

void TerminalView::OnOutput(const std::string& bytes) {
    m_pending += bytes;

    // Hold back an incomplete trailing UTF-8 sequence until the next read.
    size_t keep = m_pending.size(), i = keep;
    for (int back = 0; i > 0 && back < 4; ++back) {
        unsigned char c = static_cast<unsigned char>(m_pending[i - 1]);
        if ((c & 0xC0) == 0x80) { --i; continue; }  // continuation byte
        if (c >= 0xC0) {
            size_t need = c >= 0xF0 ? 4 : c >= 0xE0 ? 3 : 2;
            if (keep - (i - 1) < need) keep = i - 1;
        }
        break;
    }
    std::wstring wide = util::ToWide(std::string_view(m_pending.data(), keep));
    m_pending.erase(0, keep);

    m_screen.Feed(wide);
    m_dirty = true;

    std::wstring title;
    if (m_screen.TakeTitle(title) && m_onTitle) m_onTitle(title);
}

void TerminalView::OnExit(DWORD code) {
    if (m_exited) return;
    m_exited = true;
    Print(L"\r\n[Process exited with code " + std::to_wstring(static_cast<long>(code)) + L"]\r\n");
    if (code == 0 && m_onCloseRequested) m_onCloseRequested();
}

void TerminalView::Flush() {
    if (!m_dirty) return;
    m_dirty = false;
    bool follow = m_scroll.VerticalOffset() >= m_scroll.ScrollableHeight() - 2 * m_cellH;
    m_text.Text(hstring{m_screen.Render(m_cursorOn)});
    if (follow) {
        m_scroll.UpdateLayout();
        m_scroll.ChangeView(nullptr, 1.0e9, nullptr, true);
    }
}

void TerminalView::Send(std::wstring_view text) {
    if (m_session) m_session->Write(util::ToUtf8(text));
}

void TerminalView::OnChar(CharacterReceivedRoutedEventArgs const& e) {
    wchar_t ch = e.Character();
    if (ch < 0x20 || ch == 0x7F) return;  // control keys are handled in KeyDown
    if (ch >= 0xD800 && ch <= 0xDBFF) { m_highSurrogate = ch; e.Handled(true); return; }
    if (ch >= 0xDC00 && ch <= 0xDFFF) {
        if (!m_highSurrogate) return;
        wchar_t pair[2] = {m_highSurrogate, ch};
        m_highSurrogate = 0;
        Send(std::wstring_view(pair, 2));
    } else {
        Send(std::wstring_view(&ch, 1));
    }
    e.Handled(true);
}

void TerminalView::OnKeyDown(KeyRoutedEventArgs const& e) {
    using winrt::Windows::UI::Core::CoreVirtualKeyStates;
    auto down = [](VirtualKey k) {
        return (winrt::Microsoft::UI::Input::InputKeyboardSource::GetKeyStateForCurrentThread(k) &
                CoreVirtualKeyStates::Down) == CoreVirtualKeyStates::Down;
    };
    const bool ctrl = down(VirtualKey::Control), shift = down(VirtualKey::Shift), alt = down(VirtualKey::Menu);
    const VirtualKey key = e.Key();

    if (ctrl && key == VirtualKey::Tab) return;  // let TabView switch tabs
    if (ctrl && key == VirtualKey::V) { Paste(); e.Handled(true); return; }
    if (ctrl && shift && key == VirtualKey::C) { CopySelection(); e.Handled(true); return; }

    if (ctrl && !alt && key >= VirtualKey::A && key <= VirtualKey::Z) {
        wchar_t c = static_cast<wchar_t>(static_cast<int>(key) - 64);  // Ctrl+C = 0x03, ...
        Send(std::wstring_view(&c, 1));
        e.Handled(true);
        return;
    }

    const wchar_t* seq = nullptr;
    switch (key) {
    case VirtualKey::Enter: seq = L"\r"; break;
    case VirtualKey::Back: seq = L"\x7f"; break;
    case VirtualKey::Tab: seq = shift ? L"\x1b[Z" : L"\t"; break;
    case VirtualKey::Escape: seq = L"\x1b"; break;
    case VirtualKey::Up: seq = L"\x1b[A"; break;
    case VirtualKey::Down: seq = L"\x1b[B"; break;
    case VirtualKey::Right: seq = L"\x1b[C"; break;
    case VirtualKey::Left: seq = L"\x1b[D"; break;
    case VirtualKey::Home: seq = L"\x1b[H"; break;
    case VirtualKey::End: seq = L"\x1b[F"; break;
    case VirtualKey::Insert: seq = L"\x1b[2~"; break;
    case VirtualKey::Delete: seq = L"\x1b[3~"; break;
    case VirtualKey::PageUp: seq = L"\x1b[5~"; break;
    case VirtualKey::PageDown: seq = L"\x1b[6~"; break;
    default: break;
    }
    if (seq) { Send(seq); e.Handled(true); }
}

void TerminalView::CopySelection() {
    hstring sel = m_text.SelectedText();
    if (sel.empty()) return;
    DataPackage dp;
    dp.SetText(sel);
    Clipboard::SetContent(dp);
}

void TerminalView::Paste() {
    auto content = Clipboard::GetContent();
    if (!content.Contains(StandardDataFormats::Text())) return;
    auto weak = weak_from_this();
    content.GetTextAsync().Completed([weak](auto const& op, auto&&) {
        try {
            std::wstring t{op.GetResults()};
            std::wstring out;
            out.reserve(t.size());
            for (size_t i = 0; i < t.size(); ++i) {
                if (t[i] == L'\r' && i + 1 < t.size() && t[i + 1] == L'\n') continue;
                out.push_back(t[i] == L'\n' ? L'\r' : t[i]);
            }
            if (auto s = weak.lock()) s->Send(out);
        } catch (...) {}
    });
}

}  // namespace th
