#pragma once
#include "MainWindow.g.h"
#include "ITab.h"

#include <cstdint>
#include <memory>
#include <unordered_map>

namespace winrt::TermHost::implementation {

struct MainWindow : MainWindowT<MainWindow> {
    MainWindow();

    // XAML handlers
    void OnNewTab(Windows::Foundation::IInspectable const& sender, Microsoft::UI::Xaml::RoutedEventArgs const&);
    void OnTabCloseRequested(Microsoft::UI::Xaml::Controls::TabView const&,
                             Microsoft::UI::Xaml::Controls::TabViewTabCloseRequestedEventArgs const& args);
    void OnTabSelectionChanged(Windows::Foundation::IInspectable const&,
                               Microsoft::UI::Xaml::Controls::SelectionChangedEventArgs const&);
    void OnRootLoaded(Windows::Foundation::IInspectable const&, Microsoft::UI::Xaml::RoutedEventArgs const&);
    void OnRootSizeChanged(Windows::Foundation::IInspectable const&, Microsoft::UI::Xaml::SizeChangedEventArgs const&);

private:
    void AddTab(hstring const& kind);
    void CloseTabById(uint64_t id);
    void SetTabHeader(uint64_t id, hstring const& header);
    Microsoft::UI::Xaml::Controls::TabViewItem FindItem(uint64_t id);
    void UpdateTitleBarInsets();
    void ShowMessage(hstring const& title, hstring const& body);

    std::unordered_map<uint64_t, std::shared_ptr<th::ITab>> m_tabs;
    uint64_t m_nextId = 1;
};

}  // namespace winrt::TermHost::implementation

namespace winrt::TermHost::factory_implementation {
struct MainWindow : MainWindowT<MainWindow, implementation::MainWindow> {};
}  // namespace winrt::TermHost::factory_implementation
