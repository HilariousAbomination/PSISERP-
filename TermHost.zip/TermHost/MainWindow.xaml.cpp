#include "pch.h"
#include "MainWindow.xaml.h"
#if __has_include("MainWindow.g.cpp")
#include "MainWindow.g.cpp"
#endif

#include "EditorViews.h"
#include "Shells.h"
#include "TerminalView.h"

using namespace winrt;
using namespace winrt::Microsoft::UI::Xaml;
using namespace winrt::Microsoft::UI::Xaml::Controls;
using namespace winrt::Microsoft::UI::Xaml::Media;

namespace winrt::TermHost::implementation {

MainWindow::MainWindow() {
    InitializeComponent();
    Title(L"TermHost");

    // --- Windows 11 look: Mica (the "Base Alt" variant is the one meant for tabbed title bars)
    Media::MicaBackdrop mica;
    mica.Kind(Microsoft::UI::Composition::SystemBackdrops::MicaKind::BaseAlt);
    SystemBackdrop(mica);

    // --- Chrome-style: tabs live in the title bar; the footer's DragRegion drags the window
    ExtendsContentIntoTitleBar(true);
    SetTitleBar(DragRegion());
    auto appWindow = AppWindow();
    appWindow.TitleBar().PreferredHeightOption(Microsoft::UI::Windowing::TitleBarHeightOption::Tall);
    appWindow.Resize(Windows::Graphics::SizeInt32{1280, 800});

    Closed([this](auto&&, auto&&) {
        for (auto& [id, tab] : m_tabs) tab->Close();
        m_tabs.clear();
    });

    AddTab(th::FindPwsh().empty() ? L"cmd" : L"pwsh");
}

void MainWindow::UpdateTitleBarInsets() {
    auto root = Content().XamlRoot();
    if (!root) return;
    double scale = root.RasterizationScale();
    // Reserve room for the system caption buttons (min/max/close) on the right.
    RightPad().Width(GridLengthHelper::FromPixels(AppWindow().TitleBar().RightInset() / scale));
}

void MainWindow::OnRootLoaded(IInspectable const&, RoutedEventArgs const&) { UpdateTitleBarInsets(); }
void MainWindow::OnRootSizeChanged(IInspectable const&, SizeChangedEventArgs const&) { UpdateTitleBarInsets(); }

void MainWindow::OnNewTab(IInspectable const& sender, RoutedEventArgs const&) {
    AddTab(unbox_value<hstring>(sender.as<MenuFlyoutItem>().Tag()));
}

void MainWindow::OnTabCloseRequested(TabView const&, TabViewTabCloseRequestedEventArgs const& args) {
    CloseTabById(unbox_value<uint64_t>(args.Tab().Tag()));
}

void MainWindow::OnTabSelectionChanged(IInspectable const&, SelectionChangedEventArgs const&) {
    auto item = Tabs().SelectedItem().try_as<TabViewItem>();
    if (!item) return;
    uint64_t id = unbox_value<uint64_t>(item.Tag());
    DispatcherQueue().TryEnqueue([this, id] {  // after the content is in the tree
        if (auto it = m_tabs.find(id); it != m_tabs.end()) it->second->Focus();
    });
}

TabViewItem MainWindow::FindItem(uint64_t id) {
    auto items = Tabs().TabItems();
    for (uint32_t i = 0; i < items.Size(); ++i) {
        auto item = items.GetAt(i).as<TabViewItem>();
        if (unbox_value<uint64_t>(item.Tag()) == id) return item;
    }
    return nullptr;
}

void MainWindow::SetTabHeader(uint64_t id, hstring const& header) {
    if (auto item = FindItem(id)) item.Header(box_value(header));
}

void MainWindow::CloseTabById(uint64_t id) {
    if (auto item = FindItem(id)) {
        uint32_t index = 0;
        if (Tabs().TabItems().IndexOf(item, index)) Tabs().TabItems().RemoveAt(index);
    }
    if (auto it = m_tabs.find(id); it != m_tabs.end()) {
        auto tab = it->second;  // keep alive while closing (we may be inside its own callback)
        m_tabs.erase(it);
        tab->Close();
    }
    if (m_tabs.empty()) this->Close();
}

void MainWindow::ShowMessage(hstring const& title, hstring const& body) {
    ContentDialog d;
    d.XamlRoot(Content().XamlRoot());
    d.Title(box_value(title));
    d.Content(box_value(body));
    d.CloseButtonText(L"OK");
    d.ShowAsync();
}

void MainWindow::AddTab(hstring const& kind) {
    std::wstring_view k = kind;
    const uint64_t id = m_nextId++;
    std::shared_ptr<th::ITab> tab;
    std::wstring header, glyph;

    // Builds a ConPTY-backed shell tab. `this` outlives all tabs: Closed() closes every view.
    auto makeShell = [&](std::wstring const& exe, std::wstring const& args, bool admin, std::wstring const& baseName,
                         std::wstring const& note) {
        auto view = std::make_shared<th::TerminalView>();
        const std::wstring prefix = admin ? L"[Admin] " : L"";
        view->SetTitleHandler([this, id, prefix, baseName](std::wstring t) {
            SetTabHeader(id, hstring{prefix + (t.empty() ? baseName : t)});
        });
        view->SetCloseRequestedHandler([this, id] { CloseTabById(id); });
        if (!note.empty()) view->Print(note);

        th::SessionOptions o;
        o.commandLine = L"\"" + exe + L"\"" + args;
        o.workingDirectory = th::UserProfile();
        o.elevated = admin;
        view->Start(o);

        tab = view;
        header = prefix + baseName;
        glyph = admin ? L"" : L"";
    };

    if (k == L"pwsh" || k == L"pwsh-admin") {
        std::wstring exe = th::FindPwsh();
        if (exe.empty()) {
            ShowMessage(L"PowerShell 7 not found",
                        L"Install PowerShell " + hstring{th::kPwshVersion} + L" (winget install Microsoft.PowerShell).");
            return;
        }
        std::wstring ver = th::PwshFileVersion(exe), note;
        if (ver != th::kPwshVersion)
            note = std::wstring(L"[TermHost] Expected PowerShell ") + th::kPwshVersion + L" but found " +
                   (ver.empty() ? L"an unknown version" : ver) + L".\r\n";
        makeShell(exe, L" -NoLogo", k == L"pwsh-admin", L"PowerShell", note);
    } else if (k == L"cmd" || k == L"cmd-admin") {
        makeShell(th::FindCmd(), L"", k == L"cmd-admin", L"Command Prompt", L"");
    } else if (k == L"script") {
        tab = std::make_shared<th::ScriptEditorView>();
        header = L"Script Editor";
        glyph = L"";
    } else if (k == L"notepad") {
        tab = std::make_shared<th::NotepadView>();
        header = L"Scratchpad";
        glyph = L"";
    } else {
        return;
    }

    FontIconSource icon;
    icon.Glyph(hstring{glyph});
    icon.FontFamily(FontFamily{L"Segoe Fluent Icons, Segoe MDL2 Assets"});

    TabViewItem item;
    item.Header(box_value(hstring{header}));
    item.Tag(box_value(id));
    item.IconSource(icon);
    item.Content(tab->Root());

    m_tabs[id] = tab;
    Tabs().TabItems().Append(item);
    Tabs().SelectedItem(item);
}

}  // namespace winrt::TermHost::implementation
