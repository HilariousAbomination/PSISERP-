// Custom entry point (project defines DISABLE_XAML_GENERATED_MAIN) so the same
// exe can act as the UAC-elevated ConPTY broker before any WinUI code runs.
#include "pch.h"
#include "App.xaml.h"
#include "ConPtySession.h"

int WINAPI wWinMain(HINSTANCE, HINSTANCE, PWSTR, int) {
    int argc = 0;
    LPWSTR* argv = CommandLineToArgvW(GetCommandLineW(), &argc);
    if (argv && argc >= 2 && wcscmp(argv[1], L"--broker") == 0) {
        int rc = th::RunElevatedBroker(argc, argv);
        LocalFree(argv);
        return rc;
    }
    if (argv) LocalFree(argv);

    winrt::init_apartment(winrt::apartment_type::single_threaded);
    winrt::Microsoft::UI::Xaml::Application::Start([](auto&&) {
        winrt::make<winrt::TermHost::implementation::App>();
    });
    return 0;
}
